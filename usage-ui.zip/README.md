# Usage UI

A lightweight floating usage tracker for ChatGPT sessions. See message usage, time remaining, and reset time at a glance. Built for productivity.