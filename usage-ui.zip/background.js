// Background script placeholder for extension compliance.
